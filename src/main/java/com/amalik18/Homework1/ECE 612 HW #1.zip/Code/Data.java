package com.amalik18.Homework1.ProducerConsumer;

public class Data {
    private String data;

    public Data(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }
}
